<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SetupDialogForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.ChkTrace = New System.Windows.Forms.CheckBox()
        Me.ComboBoxComPort = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.BtnConnect = New System.Windows.Forms.Button()
        Me.GrpTriggers = New System.Windows.Forms.GroupBox()
        Me.ChkBattery = New System.Windows.Forms.CheckBox()
        Me.ChkScope = New System.Windows.Forms.CheckBox()
        Me.ChkRain = New System.Windows.Forms.CheckBox()
        Me.LblConnection = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GrpTriggers.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(111, 264)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(3, 3)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.Image = Global.ASCOM.SafetyBuddy.My.Resources.Resources.ASCOM
        Me.PictureBox1.Location = New System.Drawing.Point(9, 237)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(48, 56)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(6, 51)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(53, 13)
        Me.label2.TabIndex = 7
        Me.label2.Text = "COM Port"
        '
        'ChkTrace
        '
        Me.ChkTrace.AutoSize = True
        Me.ChkTrace.Location = New System.Drawing.Point(187, 237)
        Me.ChkTrace.Name = "ChkTrace"
        Me.ChkTrace.Size = New System.Drawing.Size(69, 17)
        Me.ChkTrace.TabIndex = 8
        Me.ChkTrace.Text = "Trace on"
        Me.ChkTrace.UseVisualStyleBackColor = True
        '
        'ComboBoxComPort
        '
        Me.ComboBoxComPort.FormattingEnabled = True
        Me.ComboBoxComPort.Location = New System.Drawing.Point(63, 48)
        Me.ComboBoxComPort.Name = "ComboBoxComPort"
        Me.ComboBoxComPort.Size = New System.Drawing.Size(84, 21)
        Me.ComboBoxComPort.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Comic Sans MS", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(3, 3)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(172, 34)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "Saftey Buddy"
        '
        'BtnConnect
        '
        Me.BtnConnect.Location = New System.Drawing.Point(181, 38)
        Me.BtnConnect.Name = "BtnConnect"
        Me.BtnConnect.Size = New System.Drawing.Size(75, 39)
        Me.BtnConnect.TabIndex = 23
        Me.BtnConnect.Text = "Check Connection"
        Me.BtnConnect.UseVisualStyleBackColor = True
        '
        'GrpTriggers
        '
        Me.GrpTriggers.Controls.Add(Me.ChkBattery)
        Me.GrpTriggers.Controls.Add(Me.ChkScope)
        Me.GrpTriggers.Controls.Add(Me.ChkRain)
        Me.GrpTriggers.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrpTriggers.Location = New System.Drawing.Point(9, 109)
        Me.GrpTriggers.Name = "GrpTriggers"
        Me.GrpTriggers.Size = New System.Drawing.Size(247, 122)
        Me.GrpTriggers.TabIndex = 24
        Me.GrpTriggers.TabStop = False
        Me.GrpTriggers.Text = "Triggers"
        '
        'ChkBattery
        '
        Me.ChkBattery.AutoSize = True
        Me.ChkBattery.Checked = True
        Me.ChkBattery.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkBattery.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkBattery.Location = New System.Drawing.Point(7, 68)
        Me.ChkBattery.Name = "ChkBattery"
        Me.ChkBattery.Size = New System.Drawing.Size(130, 17)
        Me.ChkBattery.TabIndex = 2
        Me.ChkBattery.Text = "Roof controller battery"
        Me.ChkBattery.UseVisualStyleBackColor = True
        '
        'ChkScope
        '
        Me.ChkScope.AutoSize = True
        Me.ChkScope.Checked = True
        Me.ChkScope.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkScope.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkScope.Location = New System.Drawing.Point(7, 44)
        Me.ChkScope.Name = "ChkScope"
        Me.ChkScope.Size = New System.Drawing.Size(195, 17)
        Me.ChkScope.TabIndex = 1
        Me.ChkScope.Text = "Scope safe for roof to open or close"
        Me.ChkScope.UseVisualStyleBackColor = True
        '
        'ChkRain
        '
        Me.ChkRain.AutoSize = True
        Me.ChkRain.Checked = True
        Me.ChkRain.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkRain.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkRain.Location = New System.Drawing.Point(7, 20)
        Me.ChkRain.Name = "ChkRain"
        Me.ChkRain.Size = New System.Drawing.Size(82, 17)
        Me.ChkRain.TabIndex = 0
        Me.ChkRain.Text = "Rain sensor"
        Me.ChkRain.UseVisualStyleBackColor = True
        '
        'LblConnection
        '
        Me.LblConnection.AutoSize = True
        Me.LblConnection.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblConnection.Location = New System.Drawing.Point(6, 81)
        Me.LblConnection.Name = "LblConnection"
        Me.LblConnection.Size = New System.Drawing.Size(51, 15)
        Me.LblConnection.TabIndex = 26
        Me.LblConnection.Text = "Version:"
        '
        'SetupDialogForm
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(269, 305)
        Me.Controls.Add(Me.LblConnection)
        Me.Controls.Add(Me.GrpTriggers)
        Me.Controls.Add(Me.BtnConnect)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.ComboBoxComPort)
        Me.Controls.Add(Me.ChkTrace)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "SetupDialogForm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Safety Buddy Setup"
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GrpTriggers.ResumeLayout(False)
        Me.GrpTriggers.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Private WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents ChkTrace As System.Windows.Forms.CheckBox
    Friend WithEvents ComboBoxComPort As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents BtnConnect As Button
    Friend WithEvents GrpTriggers As GroupBox
    Friend WithEvents ChkScope As CheckBox
    Friend WithEvents ChkRain As CheckBox
    Friend WithEvents ChkBattery As CheckBox
    Friend WithEvents LblConnection As Label
End Class
