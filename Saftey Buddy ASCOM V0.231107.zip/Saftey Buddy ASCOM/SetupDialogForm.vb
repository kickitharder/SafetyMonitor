Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports ASCOM.SafetyBuddy
Imports ASCOM.Utilities
Imports System.IO.Ports

<ComVisible(False)> _
Public Class SetupDialogForm

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click ' OK button event handler
        ' Persist new values of user settings to the ASCOM profile
        SafetyMonitor.comPort = ComboBoxComPort.SelectedItem ' Update the state variables with results from the dialogue
        SafetyMonitor.traceState = ChkTrace.Checked
        SafetyMonitor.ChkBattery = ChkBattery.Checked
        SafetyMonitor.ChkRain = ChkRain.Checked
        SafetyMonitor.ChkScope = ChkScope.Checked
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click 'Cancel button event handler
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub ShowAscomWebPage(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.DoubleClick, PictureBox1.Click
        ' Click on ASCOM logo event handler
        Try
            System.Diagnostics.Process.Start("https://ascom-standards.org/")
        Catch noBrowser As System.ComponentModel.Win32Exception
            If noBrowser.ErrorCode = -2147467259 Then
                MessageBox.Show(noBrowser.Message)
            End If
        Catch other As System.Exception
            MessageBox.Show(other.Message)
        End Try
    End Sub

    Private Sub SetupDialogForm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load ' Form load event handler
        ' Retrieve current values of user settings from the ASCOM Profile
        InitUI()
    End Sub

    Private Sub InitUI()
        ChkTrace.Checked = SafetyMonitor.traceState
        ChkRain.Checked = SafetyMonitor.ChkRain
        ChkScope.Checked = SafetyMonitor.ChkScope
        ChkBattery.Checked = SafetyMonitor.ChkBattery
        LblConnection.Text = "Version: " + SafetyMonitor.version

        ' set the list of com ports to those that are currently available
        ComboBoxComPort.Items.Clear()
        ComboBoxComPort.Items.AddRange(System.IO.Ports.SerialPort.GetPortNames())       ' use System.IO because it's static
        Dim listLength As Integer = ComboBoxComPort.Items.Count - 1                     ' Sort COM ports in number order
        Dim list(listLength) As Integer
        For i = 0 To listLength
            list(i) = Str(Mid(ComboBoxComPort.Items(i), 4, 3))
        Next
        Array.Sort(list)
        ComboBoxComPort.Items.Clear()
        For i = 0 To listLength
            ComboBoxComPort.Items.Add("COM" + list(i).ToString)
        Next
        ' select the current port if possible
        If ComboBoxComPort.Items.Contains(SafetyMonitor.comPort) Then
            ComboBoxComPort.SelectedItem = SafetyMonitor.comPort
        End If
    End Sub

    Private Sub BtnConnect_Click(sender As Object, e As EventArgs) Handles BtnConnect.Click
        If SerialCommand("A") = "A" Then
            LblConnection.Text = "Connected"
        Else
            LblConnection.Text = "Unable to connect"
        End If
    End Sub

    Public Function SerialCommand(cmdString As String) As String
        Dim retStr As String = ""
        Dim objSerial As New SerialPort
        Dim StartTime As Date = Now

        StartTime = Now
        While Now.Subtract(StartTime).TotalMilliseconds < 5000
            Try
                With objSerial
                    .PortName = ComboBoxComPort.SelectedItem
                    .BaudRate = 9600
                    .ReadTimeout = 1000
                    .WriteTimeout = 1000
                    .Open()
                    .DiscardInBuffer()
                    .DiscardOutBuffer()
                End With
                retStr = ""
                Exit While
            Catch ex As Exception
                retStr = "X Lost connection"
            End Try
        End While

        StartTime = Now
        While Now.Subtract(StartTime).TotalMilliseconds < 50    ' Wait 0.05 secs
        End While

        If retStr = "" Then
            Try
                objSerial.Write(cmdString + vbCrLf)
                retStr = objSerial.ReadTo(vbCrLf)
            Catch ex As Exception
                retStr = "X No response"
            End Try
            Try
                objSerial.Close()
                objSerial.Dispose()
            Catch ex As Exception
            End Try
        End If
        Return retStr
    End Function

End Class
